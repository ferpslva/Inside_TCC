﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Eventos
    {
        public int Id { get; set; }
        public string descricao { get; set; } = string.Empty;
        public DateTime Data { get; set; }
        public decimal valor {  get; set; }
        public int Limite_alunos { get; set; }

        /*POSTER PNG*/

        public virtual List<Inscricao> inscricoes { get; set; }
            = new List<Inscricao>();
    }
}
