﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Matricula
    {
        public int Id { get; set; }
        public int IdAluno { get; set; }
        public virtual Alunos? Alunos { get; set; }
        public DateTime Data { get; set; }
        public bool Aula_Experimental { get; set; }
        public decimal Valor_Aula { get; set; }
        public int IdPlano { get; set; }
        public virtual Plano? Plano { get; set; }
        public int IdModalidade { get; set; }
        public virtual Modalidade? Modalidade { get; set; }
        public int IdVinculo { get; set; }
        public virtual Vinculo? Vinculo { get; set; }
        public bool status {  get; set; }
    }
}
