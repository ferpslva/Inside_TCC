﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Pessoa
    {
        public int Id { get; set; }
        public string Nome { get; set; } = String.Empty;
        public string CPF { get; set; } = String.Empty;
        public string email { get; set; } = String.Empty;
        public DateTime Data_Nascimento { get; set; }
        public string telefone { get; set; } = String.Empty;
        public string CEP {  get; set; } = String.Empty;
        public string rua {  get; set; } = String.Empty;
        public int numero { get; set; }
        public string bairro { get; set; } = String.Empty;
        public string cidade { get; set; } = String.Empty;
        public string estado { get; set; } = String.Empty;
        public bool status;

        public virtual List<Incricao> incricoes { get; set; }
            = new List<Incricao>();
        public virtual List<Saida_Produto> saidas { get; set; }
            = new List<Saida_Produto>();
    }
}
