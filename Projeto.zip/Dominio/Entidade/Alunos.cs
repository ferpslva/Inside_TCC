﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Alunos:Pessoa
    {
        public int Id { get; set; }
        public bool status { get; set; }

        public virtual List<Modalidade> modalidades { get; set; }
            = new List<Modalidade>();
        public virtual List<Graduacao> graduacoes { get; set; }
            = new List<Graduacao>();
        public virtual List<Plano> plano { get; set; }
            = new List<Plano>();
        public virtual List<Aula_Aluno> aula_aluno { get; set; }
            = new List<Aula_Aluno>();
        public virtual List<Matricula> matricula { get; set; }
            = new List<Matricula>();
    }
}
