﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Professores:Pessoa
    {
        public int Id { get; set; }
        public bool status { get; set; }
        public string senha {  get; set; } = string.Empty;

        public virtual List<Modalidade> modalidades { get; set; }
            = new List<Modalidade>();
    }
}
