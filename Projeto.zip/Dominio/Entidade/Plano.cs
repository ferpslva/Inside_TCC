﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Plano
    {
        public int Id { get; set; }
        public string nome { get; set; } = string.Empty;
        public decimal valor { get; set; }
        public bool status { get; set; }
        public int IdAluno { get; set; }
        public virtual Alunos? Alunos { get; set; }
        public virtual List<Matricula> matricula { get; set; }
            = new List<Matricula>();
    }
}
