﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Tamanho
    {
        public int Id { get; set; }
        public string descricao { get; set; } = string.Empty;
        public bool status { get; set; }

        public virtual List<Produto> produtos { get; set; }
            = new List<Produto>();
    }
}
