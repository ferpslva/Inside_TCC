﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Pagamento_Evento
    {
        public int Id { get; set; }
        public int IdEvento { get; set; }
        public virtual Eventos? Eventos { get; set; }
        public bool status { get; set; }
    }
}
