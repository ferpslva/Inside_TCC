﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Mensalidade
    {
        public int Id { get; set; }
        public int IdMatricula { get; set; }
        public virtual Matricula? Matriculas { get; set; }
        public int IdPlano { get; set; }
        public virtual Plano? Planos { get; set; }
        public int IdPlano_Data { get; set; };
        public decimal Valor_Data { get; set; }
        public DateTime Data_Inicio { get; set; }
        public DateTime Data_Fim { get; set; }
        public DateTime Vencimento { get; set; }
        public int IdVinculo { get; set; }
        public virtual Vinculo? Vinculos { get; set; }
        public int IdVinculo_Data { get; set; }
        public decimal Valor_Total  { get; set; }
        public virtual List<Pagamento_Mensalidade> pagamentos_mensalidades { get; set; }
           = new List<Pagamento_Mensalidade>();
    }
}
