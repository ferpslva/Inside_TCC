﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Aula_Aluno
    {
        public int Id { get; set; }
        public int IdAluno { get; set; }
        public virtual Alunos? Alunos { get; set; }
        public int IdAula { get; set; }
        public virtual Aula? Aula { get; set; }
        public bool acesso { get; set; }
        public int IdProfessor { get; set; }
        public virtual Professores? Professores { get; set; }
    }
}
