﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Produto
    {
        public int Id { get; set; }
        public string nome { get; set; } = string.Empty;
        public int Qtde_Final { get; set; }
        public decimal valor_Credito { get; set; }
        public decimal valor_Pix {  get; set; }
        public bool status { get; set; }
        public int IdTamanho { get; set; }
        public virtual Tamanho? Tamanho { get; set; }
        public int IdTipo_Produto { get; set; }
        public virtual Tipo_Produto? Tipo_Produto { get; set; }
        public virtual List<Entrada_Produto> entradas { get; set; }
            = new List<Entrada_Produto>();
        public virtual List<Saida_Produto> saidas { get; set; }
            = new List<Saida_Produto>();
        public virtual List<Pagamento_Produto> pagamentos_produtos { get; set; }
            = new List<Pagamento_Produto>();
    }
}
