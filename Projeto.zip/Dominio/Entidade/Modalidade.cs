﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidade
{
    public class Modalidade
    {
        public int Id { get; set; }
        public string nome { get; set; } = string.Empty;
        public bool status { get; set; }
        public int IdAluno { get; set; }
        public virtual Alunos? Alunos { get; set; }
        public int IdProfessor { get; set; }
        public virtual Professores? Professores { get; set; }
        public virtual List<Graduacao> graduacoes { get; set; }
            = new List<Graduacao>();
        public virtual List<Aula> aulas { get; set; }
            = new List<Aula>();
        public virtual List<Matricula> matricula { get; set; }
            = new List<Matricula>();
    }
}
